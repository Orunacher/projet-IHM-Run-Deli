package controle ;

import java.util.ArrayList ;
import java.util.List ;

import metier.Doctor ;
import metier.Doctor ;
import metier.DoctorRecord;
import presentation.DoctorsRecord_P ;
import presentation.DoctorsRecord_P ;

//=====================================================================================
// classe de controle de la liste des docteurs
//=====================================================================================

public class DoctorsRecord_C {

   private Doctor currentDoctor ;
   private Doctor_C currentDoctor_C ;
   private Doctor_ActiveC currentDoctor_ActiveC ;
   private DoctorsRecord_P presentation ;
   private DoctorRecord abstraction ;
 
   public DoctorsRecord_C (DoctorRecord abstraction, DoctorsRecord_P presentation) {
      this.abstraction = abstraction ;
      this.presentation = presentation ;
      // dans cette version on va minimiser les créations de composans de contrôle :
      // on les crée ici et on mettra à jour leurs abstractions quand ce sera nécessaire 
      currentDoctor_C = new Doctor_C () ;
      currentDoctor_ActiveC = new Doctor_ActiveC (this) ;
      presentation.initialize (this, getDoctorsNames ()) ;
      presentation.disableActionOnSelection () ;
   }

   //-------------------------------------------------------------------------------------
   // méthode utilitaire pour construire une liste de String à partir d'une liste de Doctors
   //-------------------------------------------------------------------------------------

   private List<String> getDoctorsNames () {
      List<String> Doctors = new ArrayList<String> () ;
      for (Doctor Doctor : abstraction.getDoctors ()) {
         Doctors.add (Doctor.getLastName () + " " + Doctor.getFirstName ()) ;
      }
      return Doctors ;
   }

   //=====================================================================================
   // méthodes appelées par la présentation suite aux interactions de l'utilisateur
   //=====================================================================================

   //-------------------------------------------------------------------------------------
   // sélection d'un Doctor : on récupère l'indice du Doctor dans notre ArrayList de Doctors
   //-------------------------------------------------------------------------------------

   public void selectDoctor (int selectedIndex) {
      // on note quel est le Doctor associé à l'index de la présentation
      currentDoctor = abstraction.getDoctors ().get (selectedIndex) ;
      // on met à jour la présentation en demandant l'affichage de l'aperçu du Doctor
      currentDoctor_C.setAbstraction (currentDoctor);
      presentation.selectDoctor (currentDoctor_C.getPresentation ()) ;
      // et en activant les moyens d'édition et de destruction du Doctor sélectionné
      presentation.enableActionOnSelection () ;
      // si quelqu'un est rattaché à ce Doctor on empêche quand même de le détruire

   }

   //-------------------------------------------------------------------------------------
   // désélection d'un Doctor 
   //-------------------------------------------------------------------------------------

   public void selectNoDoctor () {
      currentDoctor = null ;
      // il n'y a plus de Doctor sélectionné, il faut faire disparaitre l'aperçu et désactiver les boutons d'actions 
      presentation.selectNoDoctor () ;
      presentation.disableActionOnSelection () ;
   }

   //-------------------------------------------------------------------------------------
   // suppression d'un Doctor dans la liste : on l'enlève dans les 2 structures pour garder la correspondance des indices
   //-------------------------------------------------------------------------------------

   public void deleteDoctor () {
      abstraction.deleteDoctor (currentDoctor) ;
      presentation.initialize (this, getDoctorsNames ()) ;
      presentation.disableActionOnSelection () ;
   }

   //-------------------------------------------------------------------------------------
   // édition du Doctor courant : on va appeler un dialogue et y mettre une présentation active de Doctor
   //-------------------------------------------------------------------------------------

   public void editDoctor () {
      currentDoctor_ActiveC.setAbstraction (currentDoctor) ;
      currentDoctor_ActiveC.activate () ;      
   }

   //-------------------------------------------------------------------------------------
   // création d'un Doctor : on va appeler un dialogue et y mettre une nouvelle présentation active de Doctor
   //-------------------------------------------------------------------------------------

   public void createDoctor () {
      Doctor Doctor = new Doctor () ;
      currentDoctor_ActiveC.setAbstraction (Doctor) ;
      currentDoctor_ActiveC.activate () ;
   }


   //-------------------------------------------------------------------------------------
   // mise à jour des caractéristiques d'un Doctor : c'est peut-être un nouveau Doctor...
   //-------------------------------------------------------------------------------------

   public void updateDoctor (Doctor_ActiveC DoctorToUpdate) {
      // si le Doctor est connu, on le met à jour
      if (abstraction.containsDoctor (DoctorToUpdate.getAbstraction ())) {
         abstraction.updateDoctor (DoctorToUpdate.getAbstraction ()) ;
      } else {
         // sinon on l'ajoute...
         abstraction.addDoctor (DoctorToUpdate.getAbstraction ()) ;
      }
      // ensuite on réinitialise la présentation pour tenir compte des éventuelles modifications
      presentation.initialize (this, getDoctorsNames ()) ;
      currentDoctor_C.setAbstraction (DoctorToUpdate.getAbstraction ());
      presentation.selectDoctor (currentDoctor_C.getPresentation ()) ;
      presentation.selectDoctor (DoctorToUpdate.toString ()) ;
   }

   //=====================================================================================
   // méthodes relai vers l'abstraction
   //=====================================================================================

   
   public List<Doctor> getDoctors () {
      return abstraction.getDoctors () ;
   }


   //=====================================================================================
   // méthode relai vers la présentation
   //=====================================================================================

   public DoctorsRecord_P getPresentation () {
      return presentation ;
   }

}