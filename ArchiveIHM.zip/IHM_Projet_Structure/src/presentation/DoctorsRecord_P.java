package presentation ;

import java.util.List ;

import controle.DoctorsRecord_C ;
import controle.PatientsRecord_C ;
import javafx.beans.value.ChangeListener ;
import javafx.beans.value.ObservableValue ;
import javafx.collections.FXCollections ;
import javafx.collections.ObservableList ;
import javafx.event.ActionEvent ;
import javafx.event.EventHandler ;
import javafx.scene.control.Button ;
import javafx.scene.control.ListView ;
import javafx.scene.control.Tab ;
import javafx.scene.layout.BorderPane ;
import javafx.scene.layout.FlowPane ;
import javafx.stage.Stage ;

//-------------------------------------------------------------------------------------
// classe de présentation de la liste des docteurs : c'est un onglet
//-------------------------------------------------------------------------------------

public class DoctorsRecord_P extends Tab {

   private ObservableList<String> doctorsNames ;
   private ListView<String> doctorsList ;
   private int currentIndex ;
   private BorderPane globalPane ;
   private Button editDoctorButton ;
   private Button deleteDoctorButton ;
   private Stage stage ;
 
   //-------------------------------------------------------------------------------------
   // constructeur : on mémorise seulement le stage principal
   //-------------------------------------------------------------------------------------
   public DoctorsRecord_P (Stage stage) {
      this.stage = stage ;    
   }
   
   //-------------------------------------------------------------------------------------
   // initialisation : on organise la présentation en accord avec le contenu à gérer
   //-------------------------------------------------------------------------------------   
   public void initialize (DoctorsRecord_C control, List<String> doctors) {
      // liste des noms des docteurs à lister
      doctorsNames = FXCollections.observableArrayList (doctors) ;
      // remplissage du widget de présentation des noms avec la liste des noms des docteurs
      doctorsList = new ListView<String> (doctorsNames) ;
      // ajout d'un listener sur la liste pour savoir quand un patient est sélectionné ou pas
      doctorsList.getSelectionModel().selectedItemProperty().addListener (new ChangeListener<String> () {
         @Override
         public void changed (ObservableValue < ? extends String> ov, String old_val, String new_val) {
            if (! doctorsList.getSelectionModel ().isEmpty ()) {
               // on essaie de trouver l'index de l'élément sélectionné
               currentIndex = doctorsList.getSelectionModel ().getSelectedIndex () ;
               // on le transfère au contrôle pour mémorisation
               control.selectDoctor (currentIndex) ;
            } else {
               // aucun docteur n'est plus sélectionné : on le signale au contrôle
               control.selectNoDoctor () ;
            }
         }
      }) ;
      
      // ajout de boutons New/Edit/Delete et des gestionnaires d'événements associés
      // c'est à chaque fois le controleur associé qui va gérer l'action à déclencher
      FlowPane buttons = new FlowPane () ;
      Button newDoctorButton = new Button () ;
      newDoctorButton.setText ("New Doctor...") ;
      newDoctorButton.setOnAction (new EventHandler<ActionEvent> () {
         @Override
         public void handle (ActionEvent event) {
            control.createDoctor () ;
         }
      }) ;
      editDoctorButton = new Button () ;
      editDoctorButton.setText ("Edit Doctor...") ;
      editDoctorButton.setOnAction (new EventHandler<ActionEvent> () {
         @Override
         public void handle (ActionEvent event) {
            control.editDoctor () ;
         }
      }) ;
      deleteDoctorButton = new Button () ;
      deleteDoctorButton.setText ("Delete") ;
      deleteDoctorButton.setOnAction (new EventHandler<ActionEvent> () {
         @Override
         public void handle (ActionEvent event) {
            control.deleteDoctor () ;
         }
      }) ;
      disableActionOnSelection () ;
      buttons.getChildren ().addAll (newDoctorButton, editDoctorButton, deleteDoctorButton) ;
      globalPane = new BorderPane () ;
      globalPane.setLeft (doctorsList) ;
      globalPane.setBottom (buttons);

      setText ("Doctors") ;
      setContent (globalPane) ;
      setClosable (false) ;
   }
   
   public Stage getStage () {
      return stage ;
   }


   //-------------------------------------------------------------------------------------
   // méthodes appelées par le contrôle associé suite à des actions de l'utilisateur ou à des changements d'états
   //-------------------------------------------------------------------------------------

   //-------------------------------------------------------------------------------------
   // désélection d'un patient
   //-------------------------------------------------------------------------------------

   public void selectNoDoctor () {
      doctorsList.getSelectionModel ().clearSelection () ;
      globalPane.setCenter (null) ;
      globalPane.autosize () ;
   }

   //-------------------------------------------------------------------------------------
   // sélection d'un patient : deux méthodes pour être plus précis dans ce que l'on demande
   //-------------------------------------------------------------------------------------

  
   public void selectDoctor (Doctor_P currentDoctor) {
     globalPane.setCenter (currentDoctor) ;
   }
     
   public void selectDoctor(String currentDoctorName) {
      doctorsList.getSelectionModel ().select (currentDoctorName) ;
   }

   //-------------------------------------------------------------------------------------
   // activation des fonctions d'édition et de suppression
   //-------------------------------------------------------------------------------------
   public void enableActionOnSelection () {
      editDoctorButton.setDisable (false) ;
      deleteDoctorButton.setDisable (false) ;      
   }

   //-------------------------------------------------------------------------------------
   // désactivation des fonctions d'édition et de suppression
   //-------------------------------------------------------------------------------------
   public void disableActionOnSelection () {
      editDoctorButton.setDisable (true) ;
      deleteDoctorButton.setDisable (true) ;                        
   }

   //-------------------------------------------------------------------------------------
   // désactivation de la fonction de suppression
   //-------------------------------------------------------------------------------------
   public void disableDeleteOnSelection () {
      deleteDoctorButton.setDisable (true) ;      
   }



}
