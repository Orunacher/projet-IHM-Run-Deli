package presentation ;

import javafx.scene.control.Label ;
import javafx.scene.layout.GridPane ;

//-------------------------------------------------------------------------------------
// classe de présentation d'un patient : elle hérite d'un GridPane
//-------------------------------------------------------------------------------------

public class Doctor_P extends GridPane {

   private Label rppsLabel ;
   private Label lastNameLabel ;
   private Label firstNameLabel ;
   private Label addressLabel ;
   private Label phoneNumberLabel ;
   private Label specialityLabel ;
   
   //-------------------------------------------------------------------------------------
   // constructeur : mémorise le controle et met en page l'affichage
   //-------------------------------------------------------------------------------------
   public Doctor_P () {
      Label rppsTitle = new Label ("RPPS : ") ;
      Label lastNameTitle = new Label ("Last Name : ") ;
      Label firstNameTitle = new Label ("First Name : ") ;
      Label addressTitle = new Label ("Address : ") ;
      Label phoneNumberTitle = new Label ("PhoneNumber :") ;
      Label specialityTitle = new Label ("Speciality :") ;
      rppsLabel = new Label () ;
      lastNameLabel = new Label () ;
      firstNameLabel = new Label () ;
      addressLabel = new Label () ;
      phoneNumberLabel = new Label () ;
      specialityLabel = new Label () ;
      addRow (0, rppsTitle, rppsLabel) ;
      addRow (1, lastNameTitle, lastNameLabel) ;
      addRow (2, firstNameTitle, firstNameLabel) ;
      addRow (3, addressTitle, addressLabel) ;
      addRow (4, phoneNumberTitle, phoneNumberLabel) ;
      addRow (5, specialityTitle, specialityLabel) ;      
   }
   
   public void update (String rpps, String lastName, String firstName, String address, String phoneNumber, String speciality) {
      rppsLabel.setText (rpps) ;
      lastNameLabel.setText (lastName) ;
      firstNameLabel.setText (firstName) ;
      addressLabel.setText (address) ;
      phoneNumberLabel.setText (phoneNumber) ;
      specialityLabel.setText (speciality) ;
   }

}