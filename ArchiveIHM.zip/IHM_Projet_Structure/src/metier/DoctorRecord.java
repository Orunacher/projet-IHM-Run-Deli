package metier;

import java.util.ArrayList;
import java.util.List;

import dao.DoctorDAO;
import dao.MedicalRecordException;

//=====================================================================================
// classe de gestion des patients et des docteurs :
// elle pourrait être paramétrée par des éléments permettant de récupérer un stockage
//=====================================================================================

public class DoctorRecord {
   
   private DoctorDAO  doctorDAO ;
     
   public DoctorRecord () {
      doctorDAO = new DoctorDAO () ;
   }


   public List<Doctor> getDoctors () {
      List<Doctor> doctors = new ArrayList<Doctor> () ;
      try {
         doctors =  doctorDAO.findAll () ;
      } catch (MedicalRecordException e) {
         e.printStackTrace();
      }
      return doctors ;
   }
   
   public boolean containsDoctor(Doctor doctor) {
      boolean contains = false ;
      try {
         contains = (doctorDAO.find (doctor.getDoctorID()) != null) ;
      } catch (MedicalRecordException e) {
      }
      return contains ;
   }

   
   public void addDoctor (Doctor doctorToCreate) {
      try {
         doctorDAO.create (doctorToCreate);
      } catch (MedicalRecordException e) {
         e.printStackTrace();
      }     
   }

   public void updateDoctor(Doctor doctor) {
      try {
         doctor = doctorDAO.update (doctor);
      } catch (MedicalRecordException e) {
         e.printStackTrace();
      }     
   }

   public void deleteDoctor (Doctor doctorToDelete) {
      try {
         doctorDAO.delete (doctorToDelete) ;
      } catch (MedicalRecordException e) {
         e.printStackTrace();
      }
   }




}